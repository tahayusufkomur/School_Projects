CREATE VIEW CompaniesView
AS
SELECT comp.TaxNo, comp.Sector, cust.CustomerName, comp.NumberOfEmployees, comp.NumberOfProjects
from Company comp, Customer cust
WHERE comp.TaxNo = cust.CustomerID

SELECT * FROM CompaniesView

CREATE VIEW IndividualView
AS
SELECT ind.IndividualSSN, cust.CustomerName, ind.IndividualMail, ind.IndividualPhoneNumber
FROM Individual ind, Customer cust
WHERE ind.IndividualSSN = cust.CustomerID

SELECT * FROM IndividualView