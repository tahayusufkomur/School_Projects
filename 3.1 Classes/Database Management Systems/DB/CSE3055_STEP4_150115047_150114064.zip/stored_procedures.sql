CREATE PROCEDURE CompanyInsert_SP
(
	@TaxNo BIGINT = 0,
	@Sector VARCHAR(20) = '',
	@CompanyName VARCHAR(20) = '',
	@NumberOfEmployees BIGINT = 0,
	@NumberOfProjects BIGINT = 0,
	@StatementType NVARCHAR(20) = ''
)
AS
BEGIN
INSERT INTO Customer (CustomerID, CustomerName)
	VALUES (@TaxNo, @CompanyName)
INSERT INTO Company (TaxNo, Sector, CompanyName, NumberOfEmployees, NumberOfProjects)
	VALUES (@TaxNo, @Sector, @CompanyName, @NumberOfEmployees, @NumberOfProjects)
END

CREATE PROCEDURE InsertIndividual_SP
(
	@IndividualSSN BIGINT,
	@FirstName VARCHAR(20),
	@LastName VARCHAR(20),
	@IndividualMail VARCHAR(50),
	@IndividualPhoneNumber VARCHAR(20)
)
AS
BEGIN
INSERT INTO Customer (CustomerID, CustomerName)
	VALUES (@IndividualSSN, @FirstName + ' ' + @LastName)
INSERT INTO Individual (IndividualSSN, FirstName, LastName, IndividualMail, IndividualPhoneNumber)
	VALUES (@IndividualSSN, @FirstName, @LastName, @IndividualMail, @IndividualPhoneNumber)
END

CREATE PROCEDURE InsertDepartment_SP
(
	@D_CompanyID BIGINT,
	@DepartmentName VARCHAR(30),
	@WorkingEmployees INT,
	@DepartmentPhoneNumber VARCHAR(20),
	@DepartmentMail VARCHAR(20)
)
AS
BEGIN
INSERT INTO Department (D_CompanyID, DepartmentName, WorkingEmployees, DepartmentPhoneNumber, DepartmentMail)
	VALUES (@D_CompanyID, @DepartmentName, @WorkingEmployees, @DepartmentPhoneNumber, @DepartmentMail)
END

CREATE PROCEDURE InsertProject_SP
(
	@P_CompanyID BIGINT,
	@P_DepartmentID BIGINT,
	@ProjectName VARCHAR(30),
	@ProjectDeadline DATETIME
)
AS
BEGIN
INSERT INTO Project (P_CompanyID, P_DepartmentID, ProjectName, ProjectDeadline)
	VALUES(@P_CompanyID, @P_DepartmentID, @ProjectName, @ProjectDeadline)
END