CREATE TRIGGER InsertEmployee ON Employee
AFTER INSERT
AS
BEGIN
UPDATE c
    SET NumberOfEmployees = NumberOfEmployees + 1
  FROM Company AS c
  INNER JOIN Employee AS e
  ON c.TaxNo = e.Employee_CompanyID;
UPDATE d
	SET WorkingEmployees = WorkingEmployees + 1
	FROM Department AS d
	INNER JOIN Employee AS e
	ON d.DepartmentID = e.Employee_DepartmentID;
END

CREATE TRIGGER DeleteEmployee ON Employee
AFTER INSERT
AS
BEGIN
UPDATE c
    SET NumberOfEmployees = NumberOfEmployees - 1
  FROM Company AS c
  INNER JOIN Employee AS e
  ON c.TaxNo = e.Employee_CompanyID;
UPDATE d
	SET WorkingEmployees = WorkingEmployees - 1
	FROM Department AS d
	INNER JOIN Employee AS e
	ON d.DepartmentID = e.Employee_DepartmentID;
END
