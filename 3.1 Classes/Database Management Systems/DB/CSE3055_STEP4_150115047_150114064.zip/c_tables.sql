CREATE TABLE Customer(
	CustomerID BIGINT PRIMARY KEY NOT NULL,
	CustomerName varchar(30) NOT NULL
);

CREATE TABLE Individual(
	IndividualSSN BIGINT PRIMARY KEY NOT NULL,
	FirstName varchar(20) NOT NULL,
	LastName varchar(20) NOT NULL,
	IndividualMail varchar(50) NOT NULL,
	IndividualPhoneNumber varchar(20) NOT NULL
);

CREATE TABLE Company(
	TaxNo BIGINT PRIMARY KEY NOT NULL,
	CompanyName VARCHAR(30) NOT NULL,
	Sector varchar(20) NOT NULL,
	NumberOfEmployees INT NOT NULL,
	NumberOfProjects INT NOT NULL
);

CREATE TABLE Department(
	DepartmentID BIGINT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	D_CompanyID BIGINT FOREIGN KEY REFERENCES Company(TaxNo) NOT NULL,
	DepartmentName VARCHAR(30) NOT NULL,
	WorkingEmployees INT NOT NULL,
	DepartmentPhoneNumber VARCHAR(20) NOT NULL,
	DepartmentMail VARCHAR(50) NOT NULL
);

CREATE TABLE Project(
	ProjectID BIGINT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	P_CompanyID BIGINT FOREIGN KEY REFERENCES Company(TaxNo) NOT NULL,
	P_DepartmentID BIGINT FOREIGN KEY REFERENCES Department(DepartmentID) NOT NULL,
	ProjectName VARCHAR(30) NOT NULL,
	ProjectDeadline DATETIME NOT NULL,
);

CREATE TABLE DepartmentProject(
	DP_ProjectID BIGINT FOREIGN KEY REFERENCES Project(ProjectID) NOT NULL,
	DP_DepartmentID BIGINT FOREIGN KEY REFERENCES Department(DepartmentID) NOT NULL,
	PRIMARY KEY (DP_PROJECTID, DP_DepartmentID),
	ProjectFinished BIT NOT NULL
);


CREATE TABLE Employee(
	EmployeeSSN BIGINT PRIMARY KEY NOT NULL,
	Employee_CompanyID BIGINT FOREIGN KEY REFERENCES Company(TaxNo) NOT NULL,
	Employee_ProjectID BIGINT FOREIGN KEY REFERENCES Project(ProjectID) NOT NULL,
	Employee_DepartmentID BIGINT FOREIGN KEY REFERENCES Department(DepartmentID) NOT NULL,
	FirstName VARCHAR(20) NOT NULL,
	LastName VARCHAR(20) NOT NULL,
	EmployeeMail VARCHAR(50) NOT NULL,
	IsSupervisor BIT NOT NULL,
	IsWorking BIT NOT NULL
);

CREATE TABLE Expense(
	ExpenseID BIGINT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	Expense_EmployeeID BIGINT FOREIGN KEY REFERENCES Employee(EmployeeSSN) NOT NULL,
	Expense_ProjectID BIGINT FOREIGN KEY REFERENCES Project(ProjectID) NOT NULL,
	CreationDate DATETIME NOT NULL,
	TotalAmount FLOAT NOT NULL,
	Approved BIT
);

CREATE TABLE Receipt(
	Receipt_EmployeeID BIGINT FOREIGN KEY REFERENCES Employee(EmployeeSSN) NOT NULL,
	Receipt_ExpenseID BIGINT FOREIGN KEY REFERENCES Expense(ExpenseID) NOT NULL,
	PRIMARY KEY (Receipt_EmployeeID, Receipt_ExpenseID),
	Description VARCHAR(50),
	Vat FLOAT NOT NULL,
	Amount FLOAT NOT NULL,
	ConsumingDate DATETIME NOT NULL,
	Category VARCHAR(20),
	PaymentType VARCHAR(20) NOT NULL
);

CREATE TABLE ProjectLine(
	ProjectID BIGINT PRIMARY KEY REFERENCES Project(ProjectID) NOT NULL,
	PL_CompanyID BIGINT FOREIGN KEY REFERENCES Company(TaxNo) NOT NULL,
	PL_CustomerID BIGINT FOREIGN KEY REFERENCES Customer(CustomerID) NOT NULL,
	ProjectQuantity BIGINT NOT NULL
);

CREATE TABLE ResidentAddress(
	AddressID BIGINT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	ResidentID BIGINT FOREIGN KEY REFERENCES Department(DepartmentID),
	City VARCHAR(30) NOT NULL,
	Town VARCHAR(30) NOT NULL,
	District VARCHAR(30) NOT NULL,
	DoorNumber VARCHAR(30) NOT NULL
);

CREATE TABLE Payment(
	Payment_EmployeeSSN BIGINT FOREIGN KEY REFERENCES Employee(EmployeeSSN) NOT NULL,
	Payment_CompanyTaxID BIGINT FOREIGN KEY REFERENCES Company(TaxNo) NOT NULL,
	PaymentAmound FLOAT NOT NULL,
	PaymentDate DATETIME NOT NULL,
	PaymentType VARCHAR NOT NULL
);


