EXEC CompanyInsert_SP
	@TaxNo = 12345678928,
	@CompanyName = 'Turkcell',
	@NumberOfEmployees = 0,
	@Sector = 'GSM',
	@NumberOfProjects = 0


EXEC InsertIndividual_SP
	@IndividualSSN = 12345678914,
	@FirstName = 'Ahmet',
	@LastName = 'Arslan',
	@IndividualMail = 'aarslan@email.com',
	@IndividualPhoneNumber = '+905330000011'

EXEC InsertDepartment_SP
	@D_CompanyID = 12345678920,
	@DepartmentName = 'Sat��',
	@WorkingEmployees = 0,
	@DepartmentPhoneNumber = '+9053300023458',
	@DepartmentMail = 'selling@allianz.com'

select * from company
select * from department
select * from project
select * from employee
SELECT * FROM ProjectLine

Insert Into ProjectLine (PL_CompanyID, PL_CustomerID, ProjectID, ProjectQuantity)
	VALUES (12345678919, 12345678918, 3, 4)

INSERT INTO Employee (EmployeeSSN, Employee_CompanyID, Employee_DepartmentID, Employee_ProjectID,
	FirstName, LastName, EmployeeMail, IsSupervisor, IsWorking)
	VALUES (1111111128, 12345678918, 5, 5, 'ad', 'soyad', 'akas@test.com', 0, 0) 

INSERT INTO DepartmentProject (DP_ProjectID, DP_DepartmentID, ManagerID, ProjectFinished)
	VALUES(3, 11, 1111111113, 0)

INSERT INTO Expense (Expense_EmployeeID, Expense_ProjectID, CreationDate, TotalAmount, Approved)
	VALUES(1111111113, 3, '2019-07-07', 127.45, 0)

INSERT INTO Receipt (Receipt_EmployeeID, Receipt_ExpenseID,
	Vat, Amount, ConsumingDate, Category, PaymentType)
	VALUES (1111111111, 8, 5.50, 27.60, '2019-05-05', 'Food', 'Cash')

INSERT INTO Payment (Payment_EmployeeSSN, Payment_CompanyTaxID, PaymentAmound, PaymentDate, PaymentType)
	VALUES (1111111112, 12345678919, 130.0, '2019-01-01', '1')

INSERT INTO ResidentAddress (ResidentID, City, Town, District, DoorNumber)
	VALUES(3, 'Istanbul', 'Kad�k�y', 'Merdivenk�y', '50')










