
public class ChanceCard implements Square {
    private String name = "Chance Square";
    private String typeName = "Card";

    private int pos;

    public ChanceCard( int pos) {
        this.pos= pos;
    }

    @Override
    public int getPosition() {
        return 0;
    }

    @Override
    public void setOwner(Player player) {

    }

    @Override
    public Player getOwner() {
        return null;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getTypeName() {
        return this.typeName;
    }

    @Override
    public boolean action(Player player, int dice, int index) {
        return false;
    }

    @Override
    public int getPrice() {
        return 0;
    }
}
