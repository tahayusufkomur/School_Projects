public class Property implements Square {

    private int purchasePrice = 0;
    private int rentPrice = 0;
    private int pos;
    private String name;
    private Player owner;
    private int groupId;
    private int numberOfPropertySquares;
    private String typeName = "Property Square";

    Player[][] owners = new Player[8][5];  //row number represents group id

    private String[] name_Arr= { "Kasımpaşa", "Dolapdere", "Sultanahmet", "Karaköy" , "Sirkeci", "Beyoğlu" , "Beşiktaş", "Taksim", "Harbiye", "Şişli", "Mecidiyeköy", "Bostancı" , "Erenköy", "Caddebostan" , "Nişantaşı",  "Teşvikiye",  "Maçka" , "Levent", "Etiler", "Bebek" , "Tarabya", "Yeniköy"};
    private Integer[] groupId_arr= {-1,0,0,1,1,1,2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,7 };

    public Property(int pos, int purchasePrice, int rentPrice, int numberOfPropertySquares, int i) {
        this.name = name_Arr[i%(name_Arr.length+1)];
        this.pos = pos;
        this.purchasePrice = purchasePrice;
        this.rentPrice = rentPrice;
        this.groupId = groupId_arr[i%(groupId_arr.length+1) +1];
        this.numberOfPropertySquares= numberOfPropertySquares;
    }

    public int getPurchasePrice() {
        return this.purchasePrice;
    }

    public void setPurchasePrice(int purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public int getRentPrice() {
        return this.rentPrice;
    }

    public void setRentPrice(int rentPrice) {
        this.rentPrice = rentPrice;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPosition(int pos) {
        this.pos = pos;
    }

    @Override
    public int getPosition() {
        return this.pos;
    }

    @Override
    public void setOwner(Player player) {
        this.owner = player;
    }

    @Override
    public Player getOwner() {
        return this.owner;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getTypeName() {
        return this.typeName;
    }

    @Override
    public int getPrice() {
        return this.purchasePrice;
    }

    public boolean action(Player player, int dice, int index) {//player will decide to whether to buy property or don't

    	 if(owner!= null) {//if property has owner player will pay the rent amount
    		if(player != this.owner) {
    		    if ((player.getMoney()- this.rentPrice) >=0){
                    player.setMoney(this.rentPrice * (-1));//decrement money of player who came to the square
                    this.owner.setMoney(this.rentPrice);//increment money of player who has property
                }
    		    else{
    		        return true;
                }
    	    }
    	 }
    	 else { //player will buy property if its money is enough and rolled dice greater than 8
    		 if(player.getMoney()-purchasePrice >=0  &&  dice >=8 ) {  //can player buy
    			 int [] returnArr = controlOwners();

    			 setOwner(player); 
    			 owners[this.groupId][returnArr[1]]= player;
    			 player.setOwnedPlaces(this);
    			 player.setMoney(purchasePrice*(-1));
    			 GameCreation.bank.setBankAmount(purchasePrice);
    			 System.out.println("Player bought " + this.name + " Square" );
    		 }
    	 }
		return false;
	}
    
    public int [] controlOwners() {//check the number of player which has the property that has the same groupId
    	
    		int common=0;		//common is a number of bought properties which have same group id by relational square's owner.
    		int loc= this.groupId*3;
			int numberOfOwner_currentGroup = 0;		//numberOfOwner_currentGroup is a number of owners of squares which have the same group id with relational square.
    		
    		while(loc+1 < groupId_arr.length && groupId_arr[loc] == groupId_arr[loc+1]) {
    			Player[] groupOwners = owners[groupId];
    			for(int i=0; i<5; i++) {
    				if(groupOwners[i] == null)
    					break;
    				numberOfOwner_currentGroup++;
    			}
    			for(int i=0; i < numberOfOwner_currentGroup; i++) {
    	    		if(owner == groupOwners[i])
    	    			common++;
    	    	}
    			loc++;
    		}
    		int [] returnarr = {common, numberOfOwner_currentGroup};
    		return returnarr;
    }
}