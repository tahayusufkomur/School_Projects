import org.junit.Assert;
import org.junit.Test;

import java.io.*;

import static org.junit.Assert.*;

public class GameCreationTest {

    @Test
    public void takeInputs() throws IOException {
        String[] inputs = new String[5];;
        File file = new File("inputs.txt");

        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;
        int i = 0;
        while ((st = br.readLine()) != null) {
            String[] tokens = st.split(":");
            inputs[i] = tokens[1];
            i++;
        }
        int numberOfPlayer= Integer.parseInt(inputs[0]);
        String [] playerNames = new String[numberOfPlayer];

        int playerNamesNumbers = Integer.parseInt(String.valueOf(playerNames.length));
        Assert.assertTrue(numberOfPlayer==playerNamesNumbers);
    }
}