package monopoly;

import java.io.IOException;

public class Main {

    public static void main(String args[]) throws IOException {

        GameCreation game = new GameCreation();
        game.play();

    }
}
