package monopoly;

public class Tax implements  Square {

    private int price;
    private int pos;
    private String name;
    private Player player;

    public Tax(String name, int price, int pos) {
        this.name = name;
        this.price = price;
    }

    public int getPrice(){
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPosition(int pos) {
        this.pos = pos;
    }

    @Override
    public int getPosition() {
        return pos;
    }

    @Override
    public void setOwner(Player player) {
        this.player = player;
    }

    @Override
    public Player getOwner() {
        return player;
    }

    @Override
    public String getName() {
        return name;
    }
}