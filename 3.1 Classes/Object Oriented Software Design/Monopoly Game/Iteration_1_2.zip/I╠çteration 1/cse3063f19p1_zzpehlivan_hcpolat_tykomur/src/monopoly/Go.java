package monopoly;

public class Go implements Square {

    private int goPrice;
    private int pos;
    private String name;
    private Player player;


    public Go(String name, int price, int pos){
        this.name= name;
        this.goPrice = price;
        this.pos = pos;
    }

    public int getPrice() {
        return goPrice;
    }

    public void setPrice(int price) {
        this.goPrice = price;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public String getSquareName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int getPosition() {
        return pos;
    }

    @Override
    public void setOwner(Player player) {
        this.player = player;
    }

    @Override
    public Player getOwner() {
        return player;
    }

    @Override
    public String getName() {
        return name;
    }
}
