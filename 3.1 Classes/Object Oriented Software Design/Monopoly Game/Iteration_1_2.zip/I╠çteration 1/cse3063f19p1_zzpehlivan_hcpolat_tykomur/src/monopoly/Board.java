package monopoly;

import java.util.ArrayList;

public class Board {

    private static ArrayList<Square> squares = new ArrayList<Square>();
    private int boardSize;
    private int price;
    private String squareName;
    private static String [] inputs ;
    static Square[] squaresBackup= new Square[40];

    public Board(int boardSize, String[] inputs){
        this.boardSize = boardSize;
        this.inputs = inputs;
    }

    public static ArrayList<Square> getSquares(){

        for(int i=0; i<40; i++){
            squares.add(squaresBackup[i]);
        }

        System.out.println(squaresBackup.length);
        return squares;
    }

     //   Board2.Tax inner = board.new Tax(200, 0);
     public int getPrice() {
         return price;
     }

    public String getSquareName() {
        return squareName;
    }

    public static void createBoard() {

        generateTaxSquare(squaresBackup);
        generateGoSquare(squaresBackup);
        generatePropertySquare(squaresBackup);
        generateStationSquare(squaresBackup);

    }

    private static void generateStationSquare(Square[] squaresBackup) {

            int numberOfStationSquares = Integer.parseInt(inputs[8]);//number of property squares that taken from user
            int purchasePrice = Integer.parseInt(inputs[9]);//amount of property that taken from user

            int[] stationPos = new int[numberOfStationSquares];//this array contains positions of property squares

            for (int i = 0; i < numberOfStationSquares; i++) {  //generated random position number to locate squares into the board
                double random = Math.random();
                int pos = (int) (random * 40 + 1);
                while(true){
                    if(pos < 40 && squaresBackup[pos] == null ){  //square object is generated with unique position number
                        //stationPos[i] = pos;
                        Square stationSquare = new Station("Station", pos, purchasePrice);

                        squaresBackup[pos] =  stationSquare;
                        break;
                    }
                    else
                        random = Math.random();
                        pos = (int) (random * 40 + 2);
                }
            }

        }

    private static void generateGoSquare(Square[] squaress) {
        int goPrice = Integer.parseInt(inputs[4]);//price of go square that taken from user
        Square goSquare = new Go("Go", goPrice, 0);
        squaress[0] =  goSquare;
    }

    private static void generateTaxSquare(Square[] squaress) {

        int numberOfTaxSquares = Integer.parseInt(inputs[2]);//number of tax squares that taken from user
        int taxAmount = Integer.parseInt(inputs[3]);//amount of tax that taken from user
        int[] taxPos = new int[numberOfTaxSquares]; //this array contains positions of tax squares

        for (int i = 0; i < numberOfTaxSquares; i++) {  //generated random position number to locate squares into the board
            double random = Math.random();
            int pos = (int) (random * 40 + 1);
            while(true){
                if(pos < 40 && squaresBackup[pos] == null ){  //square object is generated with unique position number
                    //taxPos[i] = pos;
                    Square taxSquare = new Tax("Tax", taxAmount, pos);

                    squaress[pos] =  taxSquare;
                    break;
                }
                else
                    random = Math.random();
                    pos = (int) (random * 40 + 2);
            }
        }
    }

    private static void generatePropertySquare(Square[] squaress) {

        int numberOfPropertySquares = Integer.parseInt(inputs[5]);//number of property squares that taken from user
        int purchasePrice = Integer.parseInt(inputs[6]);//amount of property that taken from user
        int rentPrice = Integer.parseInt(inputs[7]);//amount of property that taken from user

        int[] propertyPos = new int[numberOfPropertySquares];//this array contains positions of property squares

        for (int i = 0; i < numberOfPropertySquares; i++) {  //generated random position number to locate squares into the board
            double random = Math.random();
            int pos = (int) (random * 40 + 1);
            while(true){
                if(pos < 40 && squaresBackup[pos] == null ){  //square object is generated with unique position number
                   //propertyPos[i] = pos;
                    Square propertySquare = new Property("Property", pos, purchasePrice, rentPrice);

                    squaress[pos] =  propertySquare;
                    break;
                }
                else
                    random = Math.random();
                    pos = (int) (random * 40 + 2);
            }
        }
    }

    public static boolean controlTaxSquare(int[] taxNum, int willCheckIndex) {
        //To control square which player came is tax square or not
        for (int i = 0; i < taxNum.length; i++) {

            if (willCheckIndex == taxNum[i]) {
                return true;
            }
        }
        return false;
    }

}
