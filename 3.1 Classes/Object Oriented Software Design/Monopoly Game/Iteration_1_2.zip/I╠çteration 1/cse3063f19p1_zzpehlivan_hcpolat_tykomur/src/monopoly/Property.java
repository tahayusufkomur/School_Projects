package monopoly;

public class Property implements Square {

    private int purchasePrice = 0;
    private int rentPrice = 0;
    private int pos;
    private String name;
    private Player player;

    public Property(String name, int pos, int purchasePrice, int rentPrice) {
        this.name = name;
        this.pos = pos;
        this.purchasePrice = purchasePrice;
        this.rentPrice = rentPrice;
    }

    public int getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(int purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public int getRentPrice() {
        return rentPrice;
    }

    public void setRentPrice(int rentPrice) {
        this.rentPrice = rentPrice;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPosition(int pos) {
        this.pos = pos;
    }

    @Override
    public int getPosition() {
        return pos;
    }

    @Override
    public void setOwner(Player player) {
        this.player = player;
    }

    @Override
    public Player getOwner() {
        return player;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getPrice() {
        return 0;
    }
}