package monopoly;

public interface Square {

    int getPosition();
    void setOwner(Player player);
    Player getOwner();
    String getName();

    int getPrice();
}