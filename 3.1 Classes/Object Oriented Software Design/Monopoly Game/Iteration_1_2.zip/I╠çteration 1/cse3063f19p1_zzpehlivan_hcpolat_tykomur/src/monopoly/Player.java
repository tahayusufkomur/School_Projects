package monopoly;

import java.util.ArrayList;
import java.util.List;

public class Player {

    private String name;
    private int position;
    private int money;
    List<String> ownedPlaces;

    public Player(String name){
        this.name = name;
        this.money = 200;
        this.position = 0;
        this.ownedPlaces = new ArrayList<>();
    }

    public String getName() {
        return name;
    }


    public int getMoney(){
        return this.money;
    }
    /**
     * Used to update Player's money
     * @param money current amount of money
     */
    public void setMoney(int money){
        this.money += money;
    }

    /**
     * Used to update Player's position
     */
    public int getPosition(){
        return this.position;
    }

    public void setPosition(int dice){
    position=dice;
    }

    /**
     * Used to update Player's owned places
     */
    public void setOwnedPlaces(){

    }

    public static boolean controlFailure(Player player, int tax){
        if(player.money-tax <= 0){
            return false;
        }
        return true;
    }


}
