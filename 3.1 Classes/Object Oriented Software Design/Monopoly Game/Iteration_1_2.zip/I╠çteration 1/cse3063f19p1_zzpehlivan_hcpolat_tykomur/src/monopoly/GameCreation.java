package monopoly;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class GameCreation {

    private  ArrayList<Player> players;
    private  int numberOfPlayer;
    private  int goPrice;
    private  int bankAmount;
    private  Player winner;
    private  int turnCycle = 0;
    private  int countCycle = 0;
    private  boolean gameOver;
    static String[] inputs;
    String [] playerNames;
    ArrayList<Square> squares;


    public GameCreation() throws IOException {
        inputs= takeInputs();
        this.numberOfPlayer=Integer.parseInt(inputs[0]);
        this.goPrice=Integer.parseInt(inputs[4]);
        this.bankAmount= 300;
        this.gameOver = false ;
    }


    public String[] takeInputs() throws IOException {    //Function for reading input file
        inputs = new String[17];

        File file = new File("/Users/tahayusufkomur/Desktop/Dersler/Object Oriented/All İterations/İteration 1/cse3063f19p1_zzpehlivan_hcpolat_tykomur/src/monopoly/inputs.txt");

        BufferedReader br = new BufferedReader(new FileReader(file));

        String string;  //each line from input
        int i = 0;
        while ((string = br.readLine()) != null) {
            String[] tokens = string.split(":");
            inputs[i] = tokens[1];
            i++;
        }
        return inputs;
    }

    public void play() throws IOException {
        Board board = new Board(40, inputs);

        createPlayers();//Create players

        players = determineOrder(); //Determine the game order of players
        Board.createBoard(); //Create game board
        progress(); //players will play after board is generated
    }

    public void createPlayers() {

        numberOfPlayer = Integer.parseInt(inputs[0]); //number of players that given by user
        players = new ArrayList(); //create arraylist to hold players

        String [] names = inputs[1].substring(1 , inputs[1].length()-1).split(","); //names of players that given by user

        playerNames= new String[names.length];

        for (int i=0 ;i<names.length; i++){
            playerNames[i]= names[i];
        }

        for (int i = 0; i < numberOfPlayer; i++) {
            String player = playerNames[i];
            players.add(new Player(player)); //add player to the arraylist of players
        }
    }

    public void progress() {
        String failedPlayer = null;
        squares = Board.getSquares();
        while (bankAmount>=0) {
            int failedPlayerNum = 0;   //number of players that is failed
            for (int i = 0; i < numberOfPlayer; i++) {//loop for each cycle
                if(players.get(i) == null)
                    break;
                Player currentPlayer = players.get(i);
                failedPlayer= currentPlayer.getName();

                int diceNum = Dice.rollDices();
                turnCycle++;//increment turn cycle for each player's per roll
                int currPos = currentPlayer.getPosition();
                currentPlayer.setPosition((currPos + diceNum) % 40);//set current player's position according to face number

                if ((currentPlayer.getPosition() == 0 || currentPlayer.getPosition() - currPos < 0) && bankAmount>=0) {  //control condition for came to Go square after roll or passed Go square
                    currentPlayer.setMoney(goPrice);//give current player to the go price
                    bankAmount -= goPrice; //reduce bank amount
                    if (bankAmount <= 0) {//check is bank amount is over or not
                        System.out.println("The money in the bank is over!");
                        gameOver(" ");//if money in the bank is over game will over
                    }

                }
                int a= currentPlayer.getPosition();
                Square    x = null;
                x = squares.get(currentPlayer.getPosition());
                if(x == null)
                    break;
                String y= x.getName();
                if ((squares.get(currentPlayer.getPosition()).getName().equals("Tax")) && bankAmount>=0) { //came to tax square

                    int willPay = squares.get(currentPlayer.getPosition()).getPrice();//amount of money that players going to pay if it came to the tax square
                    currentPlayer.setMoney(willPay * (-1));  //tax get paid
                    bankAmount += willPay;//Increase amount of bank for each tax

                    if (currentPlayer.getMoney() < 0) {  //fail control
                        players.remove(currentPlayer);  //if player failed remove it from array list of players
                        if (controlGameOver(failedPlayer)){//check is game over or not
                            gameOver = true;
                            break;  //when remained 1 player on the game, game will over and loop will be terminated.

                        }
                        failedPlayerNum++;  //increment number of failed player
                    }
                }

                if(bankAmount<0){
                    break;
                }
                if(players.set(i,currentPlayer) == null)
                    break;
                players.set(i, currentPlayer);
                printCurrentSituation(currentPlayer);

            }

            if(gameOver)    break;  //when remained 1 player on the game, game will over and loop will be terminated.
            if(bankAmount>0)  printCycleSituation();

            countCycle++;//increment count cycle at each cycle
            numberOfPlayer -= failedPlayerNum; //calculate remain player number

            if (numberOfPlayer == 1) {//if remained number of player is 1 finish the game
                gameOver(failedPlayer);
            }
        }
    }

    public ArrayList determineOrder() {

        ArrayList<Player> order = new ArrayList<>();//array list for holding order of players
        int size = players.size();
        int[] rowPlayers = new int[size];//order of players
        System.out.println(players.size());

        for (int i = 0; i < size; i++) {//first roll dices for determine order
            rowPlayers[i] = Dice.rollDices();
        }

        int max = 0;
        int maxIndex = 0;
        for (int i = 0; i < size; i++) {//determine order of players
            for (int j = 0; j < size; j++) {
                if (rowPlayers[j] >= max) {
                    max = rowPlayers[j];
                    maxIndex = j;
                }

            }
            order.add(players.get(maxIndex));
            rowPlayers[maxIndex] = 0;
            max = 0;

        }
        return order;
    }

    public boolean gameOver(String lastFailedPlayer) {
        //Game will over when bank amount is 0 and number of player on game is 1
        winner = players.get(0);

        if(lastFailedPlayer.equals(" "))
            System.out.println( "The remain amount of bank is " + bankAmount);
        else
            System.out.println("\n"+ lastFailedPlayer + " bursted up and remained player is "+ winner.getName());


        System.out.println("\nGAME OVER");

//        players.clear();
        System.out.println("The winner is: " + winner.getName());
        System.out.println("Count Cycle: " + countCycle);
        System.out.println("Turn Cycle: " + turnCycle);
        return true;
    }

    public boolean controlGameOver(String failedPlayerName) {

        if (players.size() == 1) {
            return gameOver(failedPlayerName);
        }
        return false;

    }

    public void printCurrentSituation(Player currentPlayer) {
        //this method will be called after each player played
        System.out.println("\nCurrent player is: \n" + currentPlayer.getName());
        Dice.printDices();
        System.out.println("Current position " + (int)(currentPlayer.getPosition() + 1) + " and it is " + squares.get(currentPlayer.getPosition()).getName() + " square.");


    }

    public void printCycleSituation() {
        //this method will be called after all player played in 1 turn

        System.out.println("\nNew Cycle Balance");
        System.out.println(bankAmount);
        int size = players.size();
        int[] moneyArr = new int[size];
        int[] moneyRow = new int[size];

        for (int j = 0; j < size; j++) {
            moneyArr[j] = (int) players.get(j).getMoney();
        }

        //To print current situations of players according to money amounts after each cycle
        int max = 0;
        int maxIndex = 0;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {

                if (moneyArr[j] >= max) {
                    max = moneyArr[j];
                    maxIndex = j;
                }

            }
            moneyRow[i] = maxIndex;
            moneyArr[maxIndex] = 0;
            max = 0;

            //generated array row of player order by players price.
        }

        for (int k = 0; k < size; k++) {
            System.out.println(k+1 + ". player is " + players.get(k).getName() + " with " + players.get(k).getMoney() + " $.");
        }
    }

}
