package monopoly;

public class Station implements Square {

    private int purchasePrice = 0;
    private int rentPrice = 25;
    private int pos;
    private String name;
    private Player player;

    public Station(String name, int pos, int purchasePrice) {
        this.name = name;
        this.pos = pos;
        this.purchasePrice = purchasePrice;
    }

    public int getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(int purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public int getRentPrice() {
        return rentPrice;
    }

    public void setRentPrice(int coefficient) {
        if (coefficient == 2)
            this.rentPrice = rentPrice * coefficient;

        else if (coefficient == 3)
            this.rentPrice = 100;

        else
            this.rentPrice = 200;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPosition(int pos) {
        this.pos = pos;
    }

    @Override
    public int getPosition() {
        return pos;
    }

    @Override
    public void setOwner(Player player) {
        this.player = player;
    }

    @Override
    public Player getOwner() {
        return player;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getPrice() {
        return 0;
    }
}