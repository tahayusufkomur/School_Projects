package monopoly;

import java.util.Random;

public class Dice {

    private int num;

    public Dice(int num){
        this.num = num;

    }

    static Dice diceOne = new Dice(0);
    static Dice diceTwo = new Dice(0);

    public static int rollDices(){
        double random = Math.random();
        double random2 = Math.random();
        diceOne.num = (int) (random * 6 + 1);
        diceTwo.num = (int) (random2 * 6 + 1);
        return diceOne.num + diceTwo.num;
    }

    public static void printDices(){
        System.out.println("First dice: " + diceOne.num);
        System.out.println("Second dice: " + diceTwo.num);
    }
}
